﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Clock.Pdf;
using System.IO;
using System.Diagnostics;
using Clock.ImageProcessing;
using Clock.Util;
using System.Drawing.Imaging;
using System.Security.Cryptography;

namespace hocrgui
{
    public partial class MainWindow : Form
    {
        PdfCompressor p = null;
        string message = "Click here to select Scanned PDF's...";
        bool ocr = false;
        IList<string> Files;
        public MainWindow()
        {
            TempData.Instance.CleanAll();
            InitializeComponent();

            l.Text = message;
            cancelButton.Visible = false;
            Files = new List<string>();

            if (Directory.Exists(Properties.Settings.Default.WatchFolder))
            {
                var files = Directory.GetFiles(Properties.Settings.Default.WatchFolder, "*.pdf").ToArray();

                foreach (string s in files)
                    Files.Add(s);

                fileSystemWatcher1.Path = Properties.Settings.Default.WatchFolder;
                fileSystemWatcher1.EnableRaisingEvents = true;



            }
            if (Files.Count > 0)
            {
                l.Text = string.Concat(Files.Count, " waiting to process.", Environment.NewLine, "Click here to clear queue and add files.");

            }
        }

        private void l_Click(object sender, EventArgs e)
        {
            if (l.Text.Contains("clear"))
                Files.Clear();
            AddFiles();
        }

        void AddFiles()
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "Pdf Documents | *.pdf";
            d.Multiselect = true;
            var r = d.ShowDialog();
            if (r == System.Windows.Forms.DialogResult.Cancel)
                return;

            foreach (string s in d.FileNames)
                Files.Add(s);
            Refresh();


            backgroundWorker1.RunWorkerAsync();


        }

        void HandleOnExceptionOccurred(PdfCompressor c, Exception x)
        {
            //MessageBox.Show(x.Message);
            //l.Text = message;
            //l.Enabled = true;
            //cancelButton.Visible = false;
            //l.Refresh();
            //Refresh();
        }

        void HandleOnJobFinished(PdfCompressor c)
        {

            if (Directory.Exists(Properties.Settings.Default.SaveOriginalFilesTo))
            {
                File.Move(c.InputFileName, Path.Combine(Properties.Settings.Default.SaveOriginalFilesTo, Path.GetFileName(c.InputFileName)));
            }
            p.Cleanup();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            int cint = 1;
            backgroundWorker1.ReportProgress(cint, string.Format("Starting {0} of {1}...", cint, Files.Count));

            foreach (string s in Files)
            {
                string saveTo = string.Empty;
                if (Directory.Exists(Properties.Settings.Default.SaveProcessedFilesTo))
                {
                    saveTo = Path.Combine(Properties.Settings.Default.SaveProcessedFilesTo, Path.GetFileName(s));
                }
                else
                    saveTo = s.Replace(Path.GetExtension(s), "_cmp.pdf");

                p = new PdfCompressor(s, saveTo, Properties.Settings.Default.AutoOcr);
                p.PdfSettings.Author = Properties.Settings.Default.PDFAuthor;
                p.PdfSettings.Language = Properties.Settings.Default.Lanuguage;
                p.PdfSettings.FontName = Properties.Settings.Default.FontName;

                p.OnJobFinished += HandleOnJobFinished;
                p.OnExceptionOccurred += HandleOnExceptionOccurred;
                p.OnProgressComplete += delegate(int Page, int TotalPages, double TotalSeconds)
                {
                    string proc = string.Concat("File ", cint, " of ", Files.Count, Environment.NewLine);

                    string current = string.Format(proc + "[{0}] Processing page {1} of {2}...", Path.GetFileName(s), Page, TotalPages);

                    backgroundWorker1.ReportProgress(cint * Page, current);

                };
                p.OnPreProcessImage += new PreProcessImage(p_OnPreProcessImage);
                p.Start();
                p.Cleanup();

                cint = cint + 1;
            }
        }

        string p_OnPreProcessImage(string bitmapPath)
        {
            return bitmapPath;

            //Bitmap b = (Bitmap)Bitmap.FromFile(bitmapPath);
            //b = ImageProcessor.GetAsBitmap(b, 300);
            //if (ImageProcessor.IsGrayScale(b))
            //{
            //    return bitmapPath;
            //}
            //p.PdfSettings.ImageType = PdfImageType.Jpg;

            //b = ImageProcessor.ResizeImage(b, 96, 75);
            //var img  = ImageProcessor.ConvertToJpeg(b, 5, 96);
            //string f = TempData.Instance.CreateTempFile(".jpg");
            //TempData.Instance.Cleanup(bitmapPath);
            //img.Save(f, ImageFormat.Jpeg);
            //return f;

        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            l.Enabled = false;
            cancelButton.Visible = true;
            start.Visible = false;
            l.Text = e.UserState.ToString(); // 
            l.Refresh();

        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //  Process.Start(p.OutputFileName);
            p.Cleanup();
            l.Text = message;
            l.Enabled = true;
            cancelButton.Visible = false;
            start.Visible = true;
            Files.Clear();

            MessageBox.Show("Files are successfully converted to OCR");
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

            if (backgroundWorker1.IsBusy)
            {
                try
                {
                    p.Cancel();
                    backgroundWorker1.CancelAsync();
                }
                catch (Exception x) { }

                p.Cleanup();
                l.Text = message;
                l.Enabled = true;
                start.Visible = true;
                cancelButton.Visible = false;
            }
        }

        private void settings_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Settings s = new Settings();
            s.StartPosition = FormStartPosition.CenterParent;
            s.ShowDialog();
        }

        private void fileSystemWatcher1_Created(object sender, FileSystemEventArgs e)
        {
            Files.Add(e.FullPath);
        }

        private void start_Click(object sender, EventArgs e)
        {

            if (Files.Count > 0)
            {
                start.Visible = false;
                backgroundWorker1.RunWorkerAsync();
            }
            else
                MessageBox.Show("There are no files to process.");
        }

      
    }
}
