﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Clock.Hocr..Office;
using System.IO;
using Clock.Pdf;
using Clock.Hocr;
using System.Drawing;
using Clock.ImageProcessing;
using System.Drawing.Imaging;
using Clock.Util;
using System.Windows.Forms;
using System.Diagnostics;

namespace scratchpad
{
    class Program
    {
        static void Main(string[] args)
        {

            string pdf = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Scan0003.jpg");

          //  Clock.Pdf.PdfReader r = new Clock.Pdf.PdfReader(pdf);
            PdfCreator p = new PdfCreator(pdf.Replace(".jpg", "-NEW.pdf"));
            p.AddPage(pdf, PdfMode.Ocr);
            for (int i = 1; i <= 2; i++)
            {
                //var img = r.GetPageImage(i);

                //var bmp = (Bitmap)ImageProcessor.ConvertToImage(Image.FromFile(img), "BMP", 100, 300);
                //bmp = ImageProcessor.CropBorders(10, bmp);

                //p.AddPage(bmp, PdfMode.Ocr);
            }
            p.SaveAndClose();

        }
    }
}
