﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Appium Driver URL it works like a windows Service on your PC  
        private const string appiumDriverURI = "http://127.0.0.1:4723";
        //Application Key of your UWA   
        //U can use any .Exe file as well for open a windows Application  
        private const string calApp = "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App";

        protected static WindowsDriver<WindowsElement> calSession;
        public MainWindow()
        {
            InitializeComponent();
            if (calSession == null)
            {
                OpenQA.Selenium.Appium.AppiumOptions appiumOption = new OpenQA.Selenium.Appium.AppiumOptions();
                appiumOption.AddAdditionalCapability("app", calApp);
                appiumOption.AddAdditionalCapability("deviceName", "WindowsPC");
                DesiredCapabilities appCapabilities = new DesiredCapabilities();
                appCapabilities.SetCapability("app", calApp);
                appCapabilities.SetCapability("deviceName", "WindowsPC");
                //Create a session to intract with Calculator windows application  
                calSession = new WindowsDriver<WindowsElement>(new Uri(appiumDriverURI), appiumOption);

                //Automate Button and Get answer from Calculator  

                //find by Name  
                calSession.FindElement(By.Name("Nine")).Click();
                calSession.FindElement(By.Name("One")).Click();
                calSession.FindElement(By.Name("Two")).Click();
                calSession.FindElement(By.Name("Three")).Click();
                calSession.FindElement(By.Name("Multiply by")).Click();
                //find by automation id  
                calSession.FindElementByAccessibilityId("num9Button").Click();
                calSession.FindElementByAccessibilityId("equalButton").Click();
                //getting value from textbox  
                string ExpectedValue = calSession.FindElementByAccessibilityId("CalculatorResults").Text;
                string ExpectedValue1 = ExpectedValue.Replace("Display is ", "").Replace(",", "");

                //Testcases  
                ///Assert.AreEqual(82107, Convert.ToInt64(ExpectedValue1));
            }

        }
        Process mProcess;
        string executableName = "";
        int Port=FindFreePort();
        string folderPath = "";
        int initializeTimeout = 10;
        bool IsRunning;
        int mTerminationTimeout = 13;
        string mProcessArguments;
        public void Start()
        {
            //Do we already have our process initialized? If not, lets create a new one
            if (this.mProcess == null)
            {
                //Attempt to find a process that already exists
                Process[] processes = Process.GetProcesses();
                this.mProcess = processes.FirstOrDefault(m => m.ProcessName == executableName);

                if (this.mProcess == null)
                    this.mProcess = CreateProcess();
                else
                {
                    string cmdLine = GetCommandLine(mProcess);
                    if (cmdLine.Contains("port"))
                        this.Port = Convert.ToInt32(cmdLine.Substring(cmdLine.LastIndexOf("=") + 1));
                }
            }
        }
        private Process CreateProcess()
        {
            //If one is already running then use it.
            //if (Process.GetProcessesByName("WinAppDriver").Length == 0)
            //Process.Start(@"C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe");

            Process process = new Process();
            process = new Process();
            process.StartInfo.FileName =System.IO. Path.Combine(folderPath, executableName);
            process.StartInfo.Arguments = mProcessArguments;
            process.Start();
           // WaitUtils.Wait(() => Initialized() == true, this.initializeTimeout);
            return process;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pProcess"></param>
        /// <returns></returns>
        private string GetCommandLine(Process pProcess)
        {
            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT CommandLine FROM Win32_Process WHERE ProcessId = " + pProcess.Id))
            using (ManagementObjectCollection objects = searcher.Get())
            {
                return objects.Cast<ManagementBaseObject>().SingleOrDefault()?["CommandLine"]?.ToString();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void Stop()
        {
            if (this.IsRunning)
            {
               // WaitUtils.Wait(() => Terminated() == true, this.mTerminationTimeout);
                this.mProcess.WaitForExit(3000);
            }

            //Implement catch all feature just in case.
            if (this.IsRunning)
                this.mProcess.Kill();

            this.mProcess.Dispose();
            this.mProcess = null;
        }
        public static int FindFreePort()
        {
            int listeningPort = 0;
            Socket portSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                IPEndPoint socketEndPoint = new IPEndPoint(IPAddress.Any, 0);
                portSocket.Bind(socketEndPoint);
                socketEndPoint = (IPEndPoint)portSocket.LocalEndPoint;
                listeningPort = socketEndPoint.Port;
            }
            finally
            {
                portSocket.Close();
            }

            return listeningPort;
        }

    }
}
