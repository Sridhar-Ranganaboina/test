﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DesktopAPI.cs" company="">
//   
// </copyright>
// <summary>
//   The desktop api.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Runtime.InteropServices;

namespace TestLauncher
{
    /// <summary>
    ///     The desktop api.
    /// </summary>
    public class DesktopAPI
    {
        #region Constants

        private const uint INFINITE = 0xFFFFFFFF;
        private const int NORMAL_PRIORITY_CLASS = 0x00000020;

        #endregion

        #region Enums

        private enum DESKTOP_ACCESS : uint
        {
            DESKTOP_NONE = 0,

            DESKTOP_READOBJECTS = 0x0001,

            DESKTOP_CREATEWINDOW = 0x0002,

            DESKTOP_CREATEMENU = 0x0004,

            DESKTOP_HOOKCONTROL = 0x0008,

            DESKTOP_JOURNALRECORD = 0x0010,

            DESKTOP_JOURNALPLAYBACK = 0x0020,

            DESKTOP_ENUMERATE = 0x0040,

            DESKTOP_WRITEOBJECTS = 0x0080,

            DESKTOP_SWITCHDESKTOP = 0x0100,

            GENERIC_ALL =
                DESKTOP_READOBJECTS | DESKTOP_CREATEWINDOW | DESKTOP_CREATEMENU | DESKTOP_HOOKCONTROL
                | DESKTOP_JOURNALRECORD | DESKTOP_JOURNALPLAYBACK | DESKTOP_ENUMERATE | DESKTOP_WRITEOBJECTS
                | DESKTOP_SWITCHDESKTOP,
        }

        #endregion

        #region Public Methods and Operators

        public static void ShowSecureDesktop()
        {
            IntPtr hOldDesktop = GetThreadDesktop(GetCurrentThreadId());

            IntPtr hNewDesktop = CreateDesktop(
                "TestAppDesktop",
                IntPtr.Zero,
                IntPtr.Zero,
                0,
                (uint)DESKTOP_ACCESS.GENERIC_ALL,
                IntPtr.Zero);

            SwitchDesktop(hNewDesktop);

            SetThreadDesktop(hNewDesktop);

            var si = new STARTUPINFO();
            si.cb = Marshal.SizeOf(si);
            si.lpDesktop = "TestAppDesktop";

            var pi = new PROCESS_INFORMATION();

            CreateProcess(
                null,
                @"TestApp.exe",
                IntPtr.Zero,
                IntPtr.Zero,
                true,
                NORMAL_PRIORITY_CLASS,
                IntPtr.Zero,
                null,
                ref si,
                ref pi);

            WaitForSingleObject(pi.hProcess, INFINITE);

            SwitchDesktop(hOldDesktop);

            CloseDesktop(hNewDesktop);
        }

        #endregion

        #region Methods

        [DllImport("user32.dll")]
        private static extern bool CloseDesktop(IntPtr handle);

        [DllImport("user32.dll")]
        private static extern IntPtr CreateDesktop(
            string lpszDesktop,
            IntPtr lpszDevice,
            IntPtr pDevmode,
            int dwFlags,
            uint dwDesiredAccess,
            IntPtr lpsa);

        [DllImport("kernel32.dll")]
        private static extern bool CreateProcess(
            string lpApplicationName,
            string lpCommandLine,
            IntPtr lpProcessAttributes,
            IntPtr lpThreadAttributes,
            bool bInheritHandles,
            int dwCreationFlags,
            IntPtr lpEnvironment,
            string lpCurrentDirectory,
            ref STARTUPINFO lpStartupInfo,
            ref PROCESS_INFORMATION lpProcessInformation);

        [DllImport("kernel32.dll")]
        private static extern int GetCurrentThreadId();

        [DllImport("user32.dll")]
        private static extern IntPtr GetThreadDesktop(int dwThreadId);

        [DllImport("user32.dll")]
        private static extern bool SetThreadDesktop(IntPtr hDesktop);

        [DllImport("user32.dll")]
        private static extern bool SwitchDesktop(IntPtr hDesktop);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

        #endregion

        #region Structure

        [StructLayout(LayoutKind.Sequential)]
        private struct PROCESS_INFORMATION
        {
            public readonly IntPtr hProcess;

            public readonly IntPtr hThread;

            public readonly int dwProcessId;

            public readonly int dwThreadId;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct STARTUPINFO
        {
            public int cb;

            public readonly string lpReserved;

            public string lpDesktop;

            public readonly string lpTitle;

            public readonly int dwX;

            public readonly int dwY;

            public readonly int dwXSize;

            public readonly int dwYSize;

            public readonly int dwXCountChars;

            public readonly int dwYCountChars;

            public readonly int dwFillAttribute;

            public readonly int dwFlags;

            public readonly short wShowWindow;

            public readonly short cbReserved2;

            public readonly IntPtr lpReserved2;

            public readonly IntPtr hStdInput;

            public readonly IntPtr hStdOutput;

            public readonly IntPtr hStdError;
        }

        #endregion
    }
}